package ThoughtWorks;

/**
 * Created by donglongcheng01 on 2017/9/12.
 */
public class Result {
    private Status status;
    private String reason;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
