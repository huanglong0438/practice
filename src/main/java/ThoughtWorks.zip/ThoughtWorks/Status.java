package ThoughtWorks;

/**
 * Created by donglongcheng01 on 2017/9/12.
 */
public enum Status {
    SUCCESS,
    ERROR
}
